import { randomUUID } from 'node:crypto';
import { test, expect } from '@fixtures';
import { addressFormCountryNames } from '@resources/reference-data/reference-data';
import { skipUnlessNonStubStackEnvironment } from '@utils/playwright/environment';
import { expectRolesOptions } from '@utils/roles-options-assertions';
import type { AnimalsJourney } from '@flows/animals/journey';
import { type InsAddressBookAddPage } from '@page-objects/ins/address-book/add-page';
import { type AddressDetails } from '@page-objects/ins/address-book/form-page';
import { ADDRESS_FORM_FIELD_LABELS_IN_ORDER, ADDRESS_FORM_VALIDATION_MESSAGES } from '@domain/ins/constants/address-form';
import { journeyRolesQuestion, rolesQuestionLabels } from '@domain/ins/constants/address-book-types';
import {
  addressRoles,
  heldAsConsignee,
  heldAsConsignor,
  heldAsImporter,
  heldAsPlaceOfDestination,
  heldAsPlaceOfOrigin,
  rolesFieldOf,
  type HeldRoles,
} from '@domain/shared/constants/address-types';
import { AnimalsAddressesPage, type PartyRole } from '@page-objects/animals/addresses-page';
import { originOf } from '@page-objects/shared/base-page';

const PARTY_ROLES: readonly PartyRole[] = ['Place of origin', 'Consignor', 'Consignee', 'Importer', 'Place of destination'];

const ROLES_HELD_BY_PARTY: Record<PartyRole, HeldRoles> = {
  'Place of origin': heldAsPlaceOfOrigin,
  Consignor: heldAsConsignor,
  Consignee: heldAsConsignee,
  Importer: heldAsImporter,
  'Place of destination': heldAsPlaceOfDestination,
};

function uniqueToken(): string {
  return `${Date.now()}-${randomUUID().slice(0, 8)}`;
}

const HANDSHAKE_ADDRESS = {
  addressLine1: '9 Handshake Lane',
  townOrCity: 'Carlisle',
  postcode: 'CA2 7AA',
  phone: '01228 555 0199',
};

function newAddressFor(role: PartyRole, token: string = uniqueToken()): AddressDetails {
  return {
    ...HANDSHAKE_ADDRESS,
    name: `Handshake ${role} ${token}`,
    country: 'United Kingdom',
    email: `handshake-${token}@example.co.uk`,
  };
}

function addressAlreadyInTheBookFor(role: PartyRole, token: string) {
  return {
    ...ROLES_HELD_BY_PARTY[role],
    ...HANDSHAKE_ADDRESS,
    name: `Already in the book ${role} ${token}`,
    countryCode: 'GB',
    email: `already-${token}@example.co.uk`,
  };
}

function addedBannerText(details: AddressDetails): string {
  return `${details.name} address added to your address book`;
}

async function arriveOnInsAddPageAndFill(
  animalsJourney: AnimalsJourney,
  addPage: InsAddressBookAddPage,
  role: PartyRole,
  details: AddressDetails,
): Promise<void> {
  await animalsJourney.toInsAddAddressFromPicker(addPage, role);
  await addPage.fill(details);
}

test.describe('Add an address from the journey via INS', () => {
  test.beforeEach(() => {
    skipUnlessNonStubStackEnvironment(
      'the handshake crosses the animals and INS frontends, which both run on the compose stack and in CDP',
    );
  });

  for (const role of PARTY_ROLES) {
    test(
      `Save and select on the INS add page reached from the ${role} picker saves the address holding that role, selects it for the role and lands on Roles and addresses with the added banner`,
      { tag: ['@address-book', '@ins-frontend'] },
      async ({ animalsJourney, pages, animalsPages, insPages, addressBookApi }) => {
        const addPage = insPages.addressBookAdd;
        const details = newAddressFor(role);
        const insOrigin = originOf('TRADE_IMPORTS_INS_FRONTEND_BASE_URL');

        await arriveOnInsAddPageAndFill(animalsJourney, addPage, role, details);
        await expect(pages.page).toHaveURL((url) => url.origin === insOrigin && url.pathname === '/address-book/add' && url.search !== '');
        await expect(addPage.linkBack).toBeVisible();
        await expect(addPage.btnSaveAndSelect).toBeVisible();
        await expect(addPage.btnSaveAndReturnToAddressPage).toBeVisible();
        await expect(addPage.linkCancelAndReturnToHub).toBeVisible();

        await addPage.btnSaveAndSelect.click();

        await expect(animalsPages.addresses.heading).toBeVisible();
        await expect(animalsPages.addresses.successBanner.getByText(addedBannerText(details), { exact: true })).toBeVisible();
        await expect(animalsPages.addresses.partyAddressLines(role)).toHaveText(AnimalsAddressesPage.expectedAddressText(details), {
          useInnerText: true,
        });
        await expect(animalsPages.addresses.changeParty(role)).toBeVisible();

        const saved = await addressBookApi.findByName(details.name);
        expect(rolesFieldOf(saved)).toEqual(ROLES_HELD_BY_PARTY[role]);
      },
    );

    test(
      `Save and return to address page on the INS add page reached from the ${role} picker lands on the picker with the added banner, the new address listed first and nothing selected`,
      { tag: ['@address-book', '@ins-frontend'] },
      async ({ animalsJourney, insPages, addressBookApi }) => {
        const addPage = insPages.addressBookAdd;
        const picker = animalsJourney.partyPicker(role);
        const token = uniqueToken();
        const details = newAddressFor(role, token);
        const alreadyInTheBook = await addressBookApi.createAddress(addressAlreadyInTheBookFor(role, token));

        await animalsJourney.toPartyPicker(role);
        await animalsJourney.openInsAddAddressFromPicker(addPage, role);
        await addPage.fill(details);
        await addPage.btnSaveAndReturnToAddressPage.click();

        await expect(picker.heading).toBeVisible();
        await expect(picker.successBanner.getByText(addedBannerText(details), { exact: true })).toBeVisible();
        await expect(picker.checkedParties).toHaveCount(0);

        const added = await addressBookApi.findByName(details.name);
        await picker.search(token);
        await expect(picker.listedParties).toHaveCount(2);
        expect(await picker.listedPartyIds()).toEqual([added.id, alreadyInTheBook.id]);
        await expect(picker.checkedParties).toHaveCount(0);
      },
    );

    test(
      `Cancel and return to hub on the INS add page reached from the ${role} picker lands on the Overview and saves no address`,
      { tag: ['@address-book', '@ins-frontend'] },
      async ({ animalsJourney, animalsPages, insPages }) => {
        const addPage = insPages.addressBookAdd;
        const picker = animalsJourney.partyPicker(role);
        const details = newAddressFor(role);

        await arriveOnInsAddPageAndFill(animalsJourney, addPage, role, details);
        await addPage.linkCancelAndReturnToHub.click();

        await expect(animalsPages.overview.heading).toBeVisible();

        await animalsPages.overview.task('Roles and addresses').click();
        await expect(animalsPages.addresses.heading).toBeVisible();
        await expect(animalsPages.addresses.partyLinks(role)).toHaveText([AnimalsAddressesPage.addLinkName(role)]);

        await animalsPages.addresses.addParty(role).click();
        await expect(picker.heading).toBeVisible();
        await picker.searchBox.fill(details.name);
        await picker.searchButton.click();
        await expect(picker.noMatchesMessage).toBeVisible();
      },
    );
  }

  test(
    'Save and select on the INS add page reached from the Consignor picker shows the added banner, which is still shown ten seconds later and is gone after a reload',
    { tag: ['@address-book', '@ins-frontend'] },
    async ({ animalsJourney, pages, animalsPages, insPages }) => {
      const addPage = insPages.addressBookAdd;

      const details = newAddressFor('Consignor');

      await arriveOnInsAddPageAndFill(animalsJourney, addPage, 'Consignor', details);
      await pages.page.clock.install();
      await addPage.btnSaveAndSelect.click();
      await expect(animalsPages.addresses.heading).toBeVisible();
      const addedBanner = animalsPages.addresses.successBanner.getByText(addedBannerText(details), { exact: true });
      await expect(addedBanner).toBeVisible();

      await pages.page.clock.runFor(10_000);
      await expect(addedBanner).toBeVisible();

      await pages.page.reload();
      await expect(animalsPages.addresses.heading).toBeVisible();
      await expect(animalsPages.addresses.successBanner).toHaveCount(0);
    },
  );

  test(
    'Back on the INS add page reached from the Consignor picker lands on the Consignor picker',
    { tag: ['@address-book', '@ins-frontend'] },
    async ({ animalsJourney, insPages }) => {
      const addPage = insPages.addressBookAdd;

      await animalsJourney.toInsAddAddressFromPicker(addPage, 'Consignor');
      await addPage.linkBack.click();

      await expect(animalsJourney.partyPicker('Consignor').heading).toBeVisible();
    },
  );

  test(
    'the INS add page reached from the Consignor picker shows its page title, heading, caption, Draft status, notification reference, section headings, field labels and autocomplete hints',
    { tag: ['@address-book', '@ins-frontend'] },
    async ({ animalsJourney, journeyContext, pages, insPages }) => {
      const addPage = insPages.addressBookAdd;
      await animalsJourney.toInsAddAddressFromPicker(addPage, 'Consignor');

      await expect(pages.page).toHaveTitle('Add address and contact details - Import notification service - GOV.UK');
      await expect(addPage.heading).toBeVisible();
      await expect(addPage.caption).toBeVisible();
      await expect(addPage.statusTag).toHaveText('Draft');
      await expect(addPage.notificationReference).toHaveText(journeyContext.referenceNumber);
      await expect(addPage.sectionHeading('Address')).toBeVisible();
      await expect(addPage.sectionHeading('Contact details')).toBeVisible();
      await expect(addPage.formLabels).toHaveText([...ADDRESS_FORM_FIELD_LABELS_IN_ORDER, rolesQuestionLabels.PLACE_OF_ORIGIN]);
      await expect(addPage.inputName).not.toHaveAttribute('autocomplete');
      await expect(addPage.inputAddressLine1).toHaveAttribute('autocomplete', 'address-line1');
      await expect(addPage.inputAddressLine2).toHaveAttribute('autocomplete', 'address-line2');
      await expect(addPage.inputTownOrCity).toHaveAttribute('autocomplete', 'address-level2');
      await expect(addPage.inputPostcode).toHaveAttribute('autocomplete', 'postal-code');
      await expect(addPage.inputEmail).toHaveAttribute('autocomplete', 'email');
      await expect(addPage.inputPhone).toHaveAttribute('autocomplete', 'tel');
    },
  );

  test(
    'the INS add page reached from the Consignee picker offers United Kingdom alone, already selected',
    { tag: ['@address-book', '@ins-frontend'] },
    async ({ animalsJourney, insPages }) => {
      const addPage = insPages.addressBookAdd;

      await animalsJourney.toInsAddAddressFromPicker(addPage, 'Consignee');

      await expect(addPage.countryOptions).toHaveText(['United Kingdom']);
      await expect(addPage.selectedCountryOption).toHaveText('United Kingdom');
    },
  );

  for (const role of ['Place of origin', 'Consignor'] as const) {
    test(
      `the INS add page reached from the ${role} picker opens on Select a country and offers every captured country, alphabetically, as a plain select`,
      { tag: ['@address-book', '@ins-frontend'] },
      async ({ animalsJourney, insPages }) => {
        const addPage = insPages.addressBookAdd;

        await animalsJourney.toInsAddAddressFromPicker(addPage, role);

        await expect(addPage.selectCountry).toHaveJSProperty('tagName', 'SELECT');
        await expect(addPage.selectCountry).toHaveValue('');
        await expect(addPage.countryOptions).toHaveText(['Select a country', ...addressFormCountryNames]);
      },
    );
  }

  test(
    'The INS add page reached from the Consignee picker asks what else the address should be used for, offering Importer and Place of destination unticked, and with Importer ticked Save and select saves the address holding the consignee and importer roles',
    { tag: ['@address-book', '@ins-frontend'] },
    async ({ animalsJourney, animalsPages, insPages, addressBookApi }) => {
      const addPage = insPages.addressBookAdd;
      const details = newAddressFor('Consignee');

      await animalsJourney.toInsAddAddressFromPicker(addPage, 'Consignee');
      await expect(addPage.rolesGroup(journeyRolesQuestion.legend)).toHaveAccessibleDescription(journeyRolesQuestion.consigneeHint);
      await expectRolesOptions(addPage, journeyRolesQuestion.legend, [addressRoles.importer, addressRoles.placeOfDestination]);
      await expect(addPage.rolesOption(addressRoles.importer)).not.toBeChecked();
      await expect(addPage.rolesOption(addressRoles.placeOfDestination)).not.toBeChecked();

      await addPage.fill(details);
      await addPage.tickRoles([addressRoles.importer]);
      await addPage.btnSaveAndSelect.click();

      await expect(animalsPages.addresses.heading).toBeVisible();
      const saved = await addressBookApi.findByName(details.name);
      expect(rolesFieldOf(saved)).toEqual({
        roles: [addressRoles.consignee, addressRoles.importer],
      });
    },
  );

  test(
    'Save and return to address page on the INS add page reached from the Consignee picker with answers missing keeps the page, lists each error in field order, keeps the name and the Importer tick and saves nothing',
    { tag: ['@address-book', '@ins-frontend'] },
    async ({ animalsJourney, insPages, addressBookApi }) => {
      const addPage = insPages.addressBookAdd;
      const details = newAddressFor('Consignee');

      await animalsJourney.toInsAddAddressFromPicker(addPage, 'Consignee');
      await addPage.fill({ ...details, addressLine1: '', townOrCity: '', postcode: '', email: '', phone: '' });
      await addPage.tickRoles([addressRoles.importer]);
      await addPage.btnSaveAndReturnToAddressPage.click();

      await expect(addPage.heading).toBeVisible();
      await expect(addPage.errorSummaryLinks).toHaveText([
        ADDRESS_FORM_VALIDATION_MESSAGES.addressLine1Required,
        ADDRESS_FORM_VALIDATION_MESSAGES.townOrCityRequired,
        ADDRESS_FORM_VALIDATION_MESSAGES.postcodeRequired,
        ADDRESS_FORM_VALIDATION_MESSAGES.emailRequired,
        ADDRESS_FORM_VALIDATION_MESSAGES.phoneRequired,
      ]);
      await expect(addPage.inputName).toHaveValue(details.name);
      await expect(addPage.rolesOption(addressRoles.importer)).toBeChecked();
      expect(await addressBookApi.listAddresses(details.name)).toEqual([]);
    },
  );

  test(
    'saving the INS add page with a blank name keeps the page with the name error in the summary and on the field',
    { tag: ['@address-book', '@ins-frontend'] },
    async ({ animalsJourney, insPages }) => {
      const addPage = insPages.addressBookAdd;

      await animalsJourney.toInsAddAddressFromPicker(addPage, 'Consignee');

      await addPage.fill({
        name: '',
        addressLine1: '12 Handshake Row',
        townOrCity: 'Carlisle',
        postcode: 'CA2 7AB',
        country: 'United Kingdom',
        phone: '01228 555 0198',
        email: 'blank-name@example.co.uk',
      });
      await addPage.btnSaveAndSelect.click();

      await expect(addPage.heading).toBeVisible();
      await expect(addPage.errorSummaryLink(ADDRESS_FORM_VALIDATION_MESSAGES.nameRequired)).toBeVisible();
      await expect(addPage.inputName).toHaveAccessibleDescription(`Error: ${ADDRESS_FORM_VALIDATION_MESSAGES.nameRequired}`);
    },
  );
});
